```
http://localhost:8080/filtrarempleado?edad=22&&activo=1
```